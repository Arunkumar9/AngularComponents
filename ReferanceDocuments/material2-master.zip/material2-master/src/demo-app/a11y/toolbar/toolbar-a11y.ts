import {Component} from '@angular/core';


@Component({
  moduleId: module.id,
  selector: 'toolbar-a11y',
  templateUrl: 'toolbar-a11y.html',
  styleUrls: ['toolbar-a11y.css'],
})
export class ToolbarAccessibilityDemo {
}
