import {Component} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'menu-a11y',
  templateUrl: 'menu-a11y.html',
  styleUrls: ['menu-a11y.css'],
})
export class MenuAccessibilityDemo {
}
