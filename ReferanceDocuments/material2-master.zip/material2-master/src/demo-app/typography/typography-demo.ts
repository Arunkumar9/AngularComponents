import {Component} from '@angular/core';


@Component({
  moduleId: module.id,
  selector: 'typography-demo',
  templateUrl: 'typography-demo.html',
  styleUrls: ['typography-demo.css'],
})
export class TypographyDemo { }
