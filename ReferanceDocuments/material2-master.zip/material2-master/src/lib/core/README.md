Core library code for other `@angular/material` components.
