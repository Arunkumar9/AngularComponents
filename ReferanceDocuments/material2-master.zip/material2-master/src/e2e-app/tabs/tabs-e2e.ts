import {Component} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'tabs-e2e',
  templateUrl: 'tabs-e2e.html',
})
export class BasicTabs {}
