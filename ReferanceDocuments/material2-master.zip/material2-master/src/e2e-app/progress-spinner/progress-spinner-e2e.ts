import {Component} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'progress-spinner-e2e',
  templateUrl: 'progress-spinner-e2e.html',
})
export class ProgressSpinnerE2E { }
