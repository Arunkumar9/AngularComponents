import {Component} from '@angular/core';


@Component({
  moduleId: module.id,
  selector: 'input-e2e',
  templateUrl: 'input-e2e.html',
})
export class InputE2E {}
