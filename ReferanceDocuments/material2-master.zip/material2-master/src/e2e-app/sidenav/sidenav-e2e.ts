import {Component} from '@angular/core';


@Component({
  moduleId: module.id,
  selector: 'sidenav-e2e',
  templateUrl: 'sidenav-e2e.html',
})
export class SidenavE2E {
}
